package lapa.caio;

public class Main {
    public static void main(String[] args) {
        //Questão 01:
        //Divisao d = new Divisao();

        //Questão 02:
        //VetorInteiros vi = new VetorInteiros();

        //Questão04.txt:


    }
}