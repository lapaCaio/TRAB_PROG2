package lapa.caio.questao06;

public class Teste {
    public static void main(String[] args) {
        new MinhaTela();
    }
}
