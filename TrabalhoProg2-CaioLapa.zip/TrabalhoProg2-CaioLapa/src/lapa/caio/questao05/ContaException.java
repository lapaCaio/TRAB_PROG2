package lapa.caio.questao05;

public class ContaException extends Exception {
    public ContaException(String _mensagem) {
        super(_mensagem);
    }
}

