package lapa.caio.questao05;

import lapa.caio.questao06.MinhaTela;

public class Teste {
    public static void main(String[] args) {

    }
}
